# -*- coding: utf-8 -*-
"""
Created on Wed Apr 24 12:05:05 2019

@author: pns_com2
"""

# numeric
a = 124
a = -154
a = 0
b = 23.22      #부동소수점
b = 32.4E-3   #E표기법 
c = 0o166     #8진수 표기법
d = 0xabc     #16진수 표기법

print(5+2)
print(5-2)
print(5*2)
print(5**2)
print(5/2)
print(5%2)
print(5//2)


# string 
a = "헬로우 파이썬"   #문자형 데이터 선언
print (a)
''' 안녕하세요  	 # 세 개의 따옴표로 문자형 데이터를 선언하는 경우 
반갑습니다....'''

from __future__ import print_function 
s = str(42)
s = 'I like you' 
s[0] 
len(s) 
s[:6] 
s[7:] 
s[-1] 
s.lower() 
s.upper() 
s.startswith('I') 
s.endswith('you') 
s.isdigit() 
s.find('like')

s.replace('like','love') 
s.split(' ') 
s.split()
s2 = 'a, an, the'
s2.split(',') 
stooges = ['larry','curly','moe'] 
' '.join(stooges) 

s3 = 'The meaning of life is' 
s4 = '42' 
s3 + ' ' + s4 
s3 + ' ' + str(42) 
s5 = ' ham and cheese ' 
s5.strip()


## Conditional Statements

x = 5

if x > 0: print('positive')

if x > 0: print('positive')
else: print('zero or negative')

if x > 0:
    print('positive')
elif x == 0:
    print('zero')
else:
    print('negative')
    
if x > 0: print('positive')
'positive' if x > 0 else 'zero or negative'    

#list

empty_list = []
empty_list = list()

simpsons = ['homer', 'marge', 'bart']

simpsons[0] 
len(simpsons) 

simpsons.append('lisa') 
simpsons.extend(['itchy', 'scratchy']) 
simpsons.insert(0, 'maggie') 
simpsons.remove('bart') 
simpsons.pop(0) 
del simpsons[0] 
simpsons[0] = 'krusty' 

neighbors = simpsons + ['ned','rod','todd']

simpsons.count('lisa') 
simpsons.index('itchy') 

weekdays = ['mon','tues','wed','thurs','fri']
weekdays[0] 
weekdays[0:3] 
weekdays[:3] 
weekdays[3:] 
weekdays[-1] 
weekdays[::2] 
weekdays[::-1] 


list(reversed(weekdays))

simpsons.sort()
simpsons.sort(reverse=True) 
simpsons.sort(key=len) 

sorted(simpsons)
sorted(simpsons, reverse=True)
sorted(simpsons, key=len)

num = [1, 2, 3]
same_num = num
same_num[0] = 0 

new_num = num.copy()
new_num = num[:]
new_num = list(num)

id(num) == id(same_num) 
id(num) == id(new_num) 
num is same_num 
num is new_num 
num == same_num 
num == new_num 

[1, 2, 3] + [4, 5, 6]
["a"] * 2 + ["b"] * 3


## list conprehension


nums = [1, 2, 3, 4, 5]
cubes = []
for num in nums:
    cubes.append(num**3)

cubes = [num**3 for num in nums] 

cubes_of_even = []
for num in nums:
    if num % 2 == 0:
            cubes_of_even.append(num**3)


cubes_of_even = [num**3 for num in nums if num % 2 == 0] 

## Tuples
    

digits = (0, 1, 'two') 
digits = tuple([0, 1, 'two']) 
zero = (0,) 

digits[2] 
len(digits) 
digits.count(0) 
digits.index(1) 

digits = digits + (3, 4)

(3, 4) * 2 

bart = ('male', 10, 'simpson') 


## dictionary

empty_dict = {}
empty_dict = dict()
family = {'dad':'homer', 'mom':'marge', 'size':6}
family = dict(dad='homer', mom='marge', size=6)
list_of_tuples = [('dad','homer'), ('mom','marge'), ('size', 6)]
family = dict(list_of_tuples)
family['dad'] 
len(family) 
family.keys() 
family.values() 
family.items() 
'mom' in family
'marge' in family 
family['cat'] = 'snowball' 
family['cat'] = 'snowball ii' 
del family['cat'] 
family['kids'] = ['bart', 'lisa'] 
family.pop('dad') 

family.update({'baby':'maggie', 'grandpa':'abe'}) 
family['mom'] 
family.get('mom') 
try:
    family['grandma'] 
except KeyError as e:
    print("Error", e)


## functions

def print_text():
    print('this is text')
print_text()
def print_this(x):
    print(x)
print_this(3) 
n = print_this(3) 

def square_this(x):
    return x ** 2

square_this(3) 
var = square_this(3) 

def power_this(x, power=2):
    return x ** power
power_this(2)
power_this(2, 3) 

def stub():
    pass

def min_max(nums):
    return min(nums), max(nums)
nums = [1, 2, 3]
min_max_num = min_max(nums) 
min_num, max_num = min_max(nums) 


#Loops


range(0, 3) 
range(3) 
range(0, 5, 2) 
fruits = ['apple', 'banana', 'cherry']
for i in range(len(fruits)):
    print(fruits[i].upper())

for fruit in fruits:
    print(fruit.upper())

for i in range(10**6):
    pass

family = {'dad':'homer', 'mom':'marge', 'size':6}
for key, value in family.items():
    print(key, value)

for index, fruit in enumerate(fruits):
    print(index, fruit)

for fruit in fruits:
    if fruit == 'banana':
        print("Found the banana!")
        break 
    else:
        print("Can't find the banana")

count = 0
while count < 5:
    print("This will print 5 times")
    count += 1 


## exception handling
    
dct = dict(a=[1, 2], b=[4, 5])
key = 'c'
try:
    dct[key]
except:
    print("Key %s is missing. Add it with empty value" % key)

dct['c'] = []
print(dct)


## OOP
import math
class Shape2D:
    def area(self):
        raise NotImplementedError()
        
class Square(Shape2D):
    def __init__(self, width):
        self.width = width
    def area(self):
        return self.width ** 2
    
class Disk(Shape2D):
    def __init__(self, radius):
        self.radius = radius
    def area(self):
        return math.pi * self.radius ** 2

shapes = [Square(2), Disk(3)]

print([s.area() for s in shapes])
s = Shape2D()

try:
    s.area()
except NotImplementedError as e:
    print("NotImplementedError")
















