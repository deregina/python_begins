# -*- coding: utf-8 -*-
"""
Created on Wed May  1 15:59:34 2019

@author: pns_com2
"""

##### numpy, pandas, matplotlib 

### numpy 
    
# matrix and array
import numpy as np

data1 = [1, 2, 3, 4, 5] 
arr1 = np.array(data1)
data2 = [range(1, 5), range(5, 9)] 
arr2 = np.array(data2) 
arr2.tolist() 

np.zeros(10)
np.zeros((3, 6))
np.ones(10)
np.linspace(0, 1, 5) 
np.logspace(0, 3, 4) 

int_array = np.arange(5)
float_array = int_array.astype(float)

arr1.dtype 
arr2.dtype 
arr2.ndim 
arr2.shape 

arr2.size 
len(arr2) 


## reshaping

arr = np.arange(10, dtype=float).reshape((2, 5))
print(arr.shape)
print(arr.reshape(5, 2))

a = np.array([0, 1])
a_col = a[:, np.newaxis]
print(a_col)
#or
a_col = a[:, None]

print(a_col.T)

arr_flt = arr.flatten()
arr_flt[0] = 33
print(arr_flt)
print(arr)

arr_flt = arr.ravel()
arr_flt[0] = 33
print(arr_flt)
print(arr)

## selection

a = np.array([0, 1])
b = np.array([2, 3])
ab = np.stack((a, b)).T
print(ab)

np.hstack((a[:, None], b[:, None]))

arr = np.arange(10, dtype=float).reshape((2, 5))
arr[0] 
arr[0, 3] 
arr[0][3] 

arr[0, :] 
arr[:, 0] 
arr[:, :2] 
arr[:, 2:] 
arr2 = arr[:, 1:4] 
print(arr2)

arr2[0, 0] = 33
print(arr2)
print(arr)

print(arr[0, ::-1])

arr2 = arr[:, [1,2,3]] 
print(arr2)
arr2[0, 0] = 44
print(arr2)
print(arr)

arr2 = arr[arr > 5] 
print(arr2)
arr2[0] = 44

print(arr2)
print(arr)

arr[arr > 5] = 0
print(arr)

names = np.array(['Bob', 'Joe', 'Will', 'Bob'])
names == 'Bob' 
names[names != 'Bob'] 
(names == 'Bob') | (names == 'Will') 
names[names != 'Bob'] = 'Joe' 
np.unique(names) 

## Vectorized Operations
nums = np.arange(5)
nums * 10 
nums = np.sqrt(nums) 
np.ceil(nums) 
np.isnan(nums) 
nums + np.arange(5) 
np.maximum(nums, np.array([1, -2, 3, -4, 5])) 

vec1 = np.random.randn(10)
vec2 = np.random.randn(10)
dist = np.sqrt(np.sum((vec1 - vec2) ** 2))

rnd = np.random.randn(4, 2) 
rnd.mean()
rnd.std()
rnd.argmin() 
rnd.sum()
rnd.sum(axis=0) 
rnd.sum(axis=1) 

(rnd > 0).sum() 
(rnd > 0).any() 
(rnd > 0).all() 

np.random.seed(12234) 
np.random.rand(2, 3) 
np.random.randn(10) 
np.random.randint(0, 2, 10) 

## boradcasting
a = np.array([[ 0, 0, 0],
              [10, 10, 10],
              [20, 20, 20],
              [30, 30, 30]])
b = np.array([0, 1, 2])
print(a + b)



############# pandas ############

import pandas as pd
import numpy as np

columns = ['name', 'age', 'gender', 'job']
user1 = pd.DataFrame([['alice', 19, "F", "student"],
['john', 26, "M", "student"]], columns=columns)
    
user2 = pd.DataFrame([['eric', 22, "M", "student"],
['paul', 58, "F", "manager"]], columns=columns)
    
user3 = pd.DataFrame(dict(name=['peter', 'julie'], age=[33, 44], gender=['M', 'F'],
job=['engineer', 'scientist']))

print(user3)


# cpmcatemate dataframe
user1.append(user2)
users = pd.concat([user1, user2, user3])
print(users)


# join data frame

user4 = pd.DataFrame(dict(name=['alice', 'john', 'eric', 'julie'],
height=[165, 180, 175, 171]))
print(user4)

merge_inter = pd.merge(users, user4, on="name")
print(merge_inter)

users = pd.merge(users, user4, on="name", how='outer')
print(users)

# summarizing
users 
type(users) 
users.head() 
users.tail() 
print(users.describe()) 
users.index 
users.columns 
users.dtypes 
users.shape 
users.values 
users.info() 

print(users.describe(include='all'))
print(users.describe(include=['object'])) 

# columns selection
users['gender'] 
type(users['gender']) 
users.gender 

users[['age', 'gender']] 
my_cols = ['age', 'gender'] 
users[my_cols] 
type(users[my_cols]) 


# rows selection
df = users.copy()
df.iloc[0] 
df.iloc[0, 0] 
df.iloc[0, 0] = 55
for i in range(users.shape[0]):
    row = df.iloc[i]
    row.age *= 100 
print(df) 

df = users.copy()
df.ix[0] 
df.ix[0, "age"] 
df.ix[0, "age"] = 55
for i in range(df.shape[0]):
    df.ix[i, "age"] *= 10
print(df) 
    
#Rows selction / filtering
users[users.age < 20] 
young_bool = users.age < 20 
young = users[young_bool] 
users[users.age < 20].job 
print(young)

users[users.age < 20][['age', 'job']] 
users[(users.age > 20) & (users.gender=='M')] 
users[users.job.isin(['student', 'engineer'])] 

# Sorting
df = users.copy()
df.age.sort_values() 
df.sort_values(by='age') 
df.sort_values(by='age', ascending=False) 
df.sort_values(by=['job', 'age']) 
df.sort_values(by=['job', 'age'], inplace=True) 
print(df)

# Reshaping by pivoting
staked = pd.melt(users, id_vars="name", var_name="variable", value_name="value")
print(staked)
print(staked.pivot(index='name', columns='variable', values='value'))

df = users.append(df.iloc[0], ignore_index=True)
print(df.duplicated()) 

df.duplicated().sum() 
df[df.duplicated()] 
df.age.duplicated() 
df.duplicated(['age', 'gender']).sum() 
df = df.drop_duplicates() 

# missing data
df = users.copy()
df.describe(include='all') 

df.height.isnull() 
df.height.notnull() 
df[df.height.notnull()] 
df.height.isnull().sum() 

df.isnull() 
df.isnull().sum() 

df.dropna() 
df.dropna(how='all') 
df.height.mean()

df = users.copy()
df.ix[df.height.isnull(), "height"] = df["height"].mean()
print(df)

# dealing outiers
size = pd.Series(np.random.normal(loc=175, size=20, scale=10))

size[:3] += 500

size_outlr_mean = size.copy()
size_outlr_mean[((size - size.mean()).abs() > 3 * size.std())] = size.mean()
print(size_outlr_mean.mean())

mad = 1.4826 * np.median(np.abs(size - size.median()))
size_outlr_mad = size.copy()
size_outlr_mad[((size - size.median()).abs() > 3 * mad)] = size.median()
print(size_outlr_mad.mean(), size_outlr_mad.median())

# group by

for grp, data in users.groupby("job"):
    print(grp, data)


# File I/O
import tempfile, os.path
tmpdir = tempfile.gettempdir()
csv_filename = os.path.join(tmpdir, "users.csv")
users.to_csv(csv_filename, index=False)
other = pd.read_csv(csv_filename)

url = 'https://raw.github.com/neurospin/pystatsml/master/data/salary_table.csv'
salary = pd.read_csv(url)

xls_filename = os.path.join(tmpdir, "users.xlsx")
users.to_excel(xls_filename, sheet_name='users', index=False)
pd.read_excel(xls_filename, sheetname='users')

with pd.ExcelWriter(xls_filename) as writer:
    users.to_excel(writer, sheet_name='users', index=False)
    df.to_excel(writer, sheet_name='salary', index=False)
    
pd.read_excel(xls_filename, sheetname='users')
pd.read_excel(xls_filename, sheetname='salary')

# 기초분석
gm = pd.read_csv("http://freakonometrics.free.fr/german_credit.csv")
gm["Credit Amount"].min() # Credit Amount 최소값
gm["Credit Amount"].max() # Credit Amount 최대값
gm["Duration of Credit (month)"].mean() #Duration of Credit (month) 평균
gm[["Credit Amount", "Duration of Credit (month)"]].describe() #요약

gm_sam = gm[['Creditability',"Account Balance", "Age (years)"]]
gm_sam.cov()
gm_sam.corr()

gm_gp = gm["Credit Amount"].groupby(gm["Length of current employment"])
gm_gp.mean()

gm_gp2 = gm["Credit Amount"].groupby([gm["Purpose"], gm["Length of current employment"]])
gm_gp2.mean()

gm_gp = gm["Credit Amount"]. groupby(gm["Purpose"])


gm_sam = gm[["Purpose","Sex & Marital Status", "Credit Amount"]]
for type, group in gm_sam.groupby("Purpose"):
    print(type)
    print(group.head(n = 3))

for (type, sex), group in gm_sam.groupby(["Purpose", "Sex & Marital Status"]):
    print((type, sex))
    print(group.head(n = 3))



# Matplotlib
    
# 기본예제
    
from matplotlib import pyplot as plt
import numpy as np 
x = np.arange(1,10,0.1)
y = x*0.2
y2 = np.sin(x)
plt.plot(x,y,'b',label='first')      # 첫 번째 Axes 설정        
plt.plot(x,y2,'r',label='second') # 두 번째 Axes 설정
plt.xlabel('x axis')                 # x축 이름 
plt.ylabel('y axis')	     # y축 이름 설정
plt.title('matplotlib sample')   # 그래프의 이름 설정
plt.legend(loc='upper right')  # 그래프의 범례 설정
plt.show()                          # 그래프 시각화

# line plot
import numpy as np
import matplotlib.pyplot as plt
x = np.linspace(0, 10, 50)
sinus = np.sin(x)
plt.plot(x, sinus)
plt.show()

# scatter plot
plt.plot(x, sinus, "o")
plt.show()

# multi plot
cosinus = np.cos(x)
plt.plot(x, sinus, "-b", x, sinus, "ob", x,
             cosinus, "-r", x, cosinus, "or")
plt.xlabel('this is x!')
plt.ylabel('this is y!')
plt.title('My First Plot')
plt.show()

plt.plot(x, sinus, label='sinus', color='blue', linestyle='--', linewidth=2)
plt.plot(x, cosinus, label='cosinus',   
      color='red', linestyle='-', linewidth=2)
plt.legend()
plt.show()


# multi scatter plot
import pandas as pd
try:
       salary = pd.read_csv("../data/salary_table.csv")
except:
       url = 'https://raw.github.com/duchesnay/pylearn-doc/master/data/salary_table.csv'
       salary = pd.read_csv(url)
df = salary
colors = colors_edu = {'Bachelor':'r', 'Master':'g', 'Ph.D':'blue'}
symbols_manag = {'Y':'*', 'N':'.'}
plt.scatter(df['experience'], df['salary'], 
	c=df['education'].apply(lambda x:colors[x]), s=100)

for values, d in salary.groupby(['education','management']):
      edu, manager = values
      plt.scatter(d['experience'], d['salary'], marker=symbols_manag[manager],
                    color=colors_edu[edu], s=150, label=manager+"/"+edu)
      
## Set labels
plt.xlabel('Experience')
plt.ylabel('Salary')
plt.legend(loc=4) # lower right
plt.show()

#box plot
import seaborn as sns
sns.boxplot(x="education", y="salary", hue="management", data=salary, palette="PRGn")
sns.boxplot(x="management", y="salary", hue="education", data=salary, palette="PRGn")


#density plot
f, axes = plt.subplots(3, 1, figsize=(9, 9), sharex=True)
i = 0
for edu, d in salary.groupby(['education']):
       sns.distplot(d.salary[d.management == "Y"], 
                       color="b", bins=10, 
	         label="Manager",ax=axes[i])
       sns.distplot(d.salary[d.management == "N"], 
                       color="r", bins=10, 
 	         label="Employee",ax=axes[i])
       axes[i].set_title(edu)
       axes[i].set_ylabel('Density')
       i += 1
plt.legend()

